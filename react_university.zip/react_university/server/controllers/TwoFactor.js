import twilio from 'twilio';

const accountSid = "ACdc73f7de990f3c6c6f5ca25aa34bdb04";
const authToken = "3d4009be755dcba6e252baa3aeba5fd6";
const serviceSid = "VA8238e9eb9436f073596891b62947b415";
const client = twilio(accountSid, authToken);

export const startVerification = async(req,res)=>{
    const phone = req.body.phone;
    if (!phone ) {
        return res.status(400).json({ message: 'Phone number are required.' });
    }
    client.verify.v2
    .services(serviceSid)
    .verifications.create({ to: phone , channel: 'sms' })
    .then(verification => {
      res.status(200).json({
        message: 'Verification initiated.',
        sid: verification.sid,
        status: verification.status,
      });
    })
    .catch(error => {
      res.status(500).json({ message: 'Error initiating verification.', error: error.message });
    });
}

export const checkVerification = (req, res) => {
    const { phone, code } = req.body;
  
    if (!phone || !code) {
      return res.status(400).json({ status:'error',message: 'Phone number and verification code are required.' });
    }
  
    client.verify.v2
    .services(serviceSid)
    .verificationChecks.create({ to: phone, code: code })
    .then(verificationCheck => {
        if (verificationCheck.status === 'approved') {
        res.status(200).json({ message: 'Verification successful.', status: verificationCheck.status });
        } else {
        res.status(400).json({ message: 'Invalid code.', status: verificationCheck.status });
        }
    })
    .catch(error => {
        res.status(500).json({ message: 'Error verifying code.', error: error.message });
    });
};

export const SendSms = async(req,res)=>{
  const to = req.query.to;
  const message = req.body.message;
  const client1 = twilio("ACdf2e51dab022b09cb92006a85ab0dc0e", "0ee5c0d9a4474bc39bef0a477b1a1424");
  const response = await client1.messages.create({
          body: message,
          from: "+18456663929", // Twilio phone number
          to: "+91"+to, // Recipient phone number
      });
      if (response.sid) {
        return res.status(200).send({status:"success"});
      }
      return res.status(200).send();
};