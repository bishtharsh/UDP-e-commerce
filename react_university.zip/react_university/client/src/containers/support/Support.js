import React from 'react'
import Header from '../../components/Header'

function Support() {
  return (
    <div><Header/></div>
  )
}

export default Support