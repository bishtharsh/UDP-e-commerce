import React from 'react'
import Header from '../../components/Header'

function Contact() {
  return <div>
    <Header/>
  </div>;
}

export default Contact