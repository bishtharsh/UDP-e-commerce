import './App.css';
import Navigation from './navigations/Navigation.js';

function App() {
  return <div className="App">
    <Navigation />
  </div>;
}

export default App;
